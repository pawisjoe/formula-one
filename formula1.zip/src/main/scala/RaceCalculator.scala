/**
  * Created by pawisjoe on 3/25/2017 AD.
  */
import scala.collection.mutable.ListBuffer

class RaceCalculator(teamNumber: Int, trackLength: Double) {
  val handlingFactor: Double = 0.8
  val handlingDistance: Double = 10
  val reAssessmentTime: Double = 2
  val teams: List[Team] = initRacingTeam()
  var currentTime: Double = 0
  val orderingByPosition: Ordering[Team] = Ordering.by(t => t.currentPosition)

  def initRacingTeam(): List[Team] = {
    val teams = scala.collection.mutable.ListBuffer.empty[Team]
    for(i <- 1 to teamNumber) {
      teams += new Team(i)
    }
    teams.toList
  }

  def calculatateRaceResult(): List[RaceResult] = {
    val results = ListBuffer.empty[RaceResult]
    while(results.size != teamNumber) {
      currentTime += reAssessmentTime

    }
    results.toList
  }

  def updatePosition(): Unit = {
    for(team <- teams) {
      if(team.getTimeToMaxSpeed() > reAssessmentTime) {
        team.updateDistanceTravelled(reAssessmentTime)
        team.updateCurrentSpeed(reAssessmentTime)
      }
      else {
        team.updateDistanceTravelled(team.getTimeToMaxSpeed())
        team.updateDistanceTravelledWithMaxSpeed(reAssessmentTime - team.getTimeToMaxSpeed())
        team.updateCurrentSpeedToMax()
      }
    }

  }

  def checkNearbyCarAndAdjustSpeed(): Unit = {

  }

  def checkLastPositionAndUseNitro(): Unit = {
    val sortedList: List[Team] = teams
    val lastTeam = teams(sortedList.sorted(orderingByPosition).last.id)
    lastTeam.useNitro()
    for(team <- teams) {
      if(team.currentPosition == lastTeam.currentPosition) {
        team.useNitro()
      }
    }
  }

  def checkFinishingCar(): Unit = {
    val finishedTeams = ListBuffer.empty[Team]
    for(team <- teams) {
      if(team.currentPosition >= trackLength) {
        team.isFinished = true
        team.finishedTime = currentTime
        finishedTeams += team
      }
    }
    removeFinishedTeam(finishedTeams, teams)
  }

  def printResult(result: List[RaceResult]) = {

  }

  def removeFinishedTeam(finishedTeams: ListBuffer[Team], list: List[Team]) = list diff finishedTeams.toList
}
