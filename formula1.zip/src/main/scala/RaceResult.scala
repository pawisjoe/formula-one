/**
  * Created by pawisjoe on 3/25/2017 AD.
  */
case class RaceResult(id: Int, finalSpeed: Double, completedTime: Int)
